package com.rays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSimple01Application {

	public static void main(String[] args) {

		SpringApplication.run(SpringBootSimple01Application.class, args);

	}

}
